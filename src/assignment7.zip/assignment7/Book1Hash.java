package assignment7;

public class Book1Hash {

}
