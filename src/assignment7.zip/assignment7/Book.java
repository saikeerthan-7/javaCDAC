package assignment7;

public class Book {
	
	int bookId;
	String title;
	String author;
	float price;
	

	public Book(int bookId, String title, String author, float price) {
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.price = price;
	}
	public void displayBook() {
		System.out.println(bookId + title + author + price);
	}


	

}
