/**
 * 
 */
/**
 * 
 */
module javaPratice {
}